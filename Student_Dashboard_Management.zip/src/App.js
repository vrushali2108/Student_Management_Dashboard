import './StudentDashboard.css';
import React, { useState } from 'react';
import StudentForm from './components/StudentForm';
import StudentList from './components/StudentList';

function App() {
  const [students, setStudents] = useState([]);
  const [editingIndex, setEditingIndex] = useState(null);
  





  // Add new or update existing student

  const handleAddStudent = (newStudent) => {
    if (editingIndex !== null) {
      const updated = [...students];
      updated[editingIndex] = newStudent;
      setStudents(updated);
      setEditingIndex(null);
    } else {
      setStudents([...students, newStudent]);
    }
  };



  // Set the index of the student being edited


  const handleEditStudent = (index) => {
    setEditingIndex(index);
  };

  return (
  <div className="dashboard-container">
    <h1>Student Management Dashboard</h1>
    <StudentForm
      onAddStudent={handleAddStudent}
      editingStudent={students[editingIndex]}
    />
    <StudentList students={students} onEdit={handleEditStudent} />
  </div>
);

}

export default App;

  
