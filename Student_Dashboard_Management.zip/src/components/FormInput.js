import React from 'react';

const FormInput = ({ label, name, value, onChange, error }) => {
  return (
    <div>
      <label>{label}:</label><br />
      <input name={name} value={value} onChange={onChange} />
      {error && <div style={{ color: 'red' }}>{error}</div>}
    </div>
  );
};

export default FormInput;
