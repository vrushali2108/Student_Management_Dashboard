import { useEffect, useState } from 'react';
import { simulateAsyncProcess } from '../utils/eventLoopDemo';
import FormInput from './FormInput';
import { fetchCourses } from '../services/api';

const StudentForm = ({ onAddStudent, editingStudent }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    course: '',
    image: ''
  });

  useEffect(() => {
  //  Demonstrating event loop behavior with async/await and setTimeout
  simulateAsyncProcess();
}, []);


  const [errors, setErrors] = useState({});
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  

  // Populate dropdown on load

  useEffect(() => {
    const getCourses = async () => {
      try {
        const data = await fetchCourses();
        setCourses(data);
      } catch (err) {
        console.error("Failed to fetch courses");
      } finally {
        setLoading(false);
      }
    };
    getCourses();
  }, []);
  



  // Load data into form when editing


  useEffect(() => {
    if (editingStudent) {
      setFormData(editingStudent);
    }
  }, [editingStudent]);
  




  //  Function to validate form inputs before submission




  const validate = () => {
    const err = {};

    // Name is required
    if (!formData.name) err.name = "Name is required";


    // Email is required and must be in correct format
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) err.email = "Valid email required";



    // Course must be selected
    if (!formData.course) err.course = "Please select a course";


    return err;   // return any errors found
  };


  
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  

  //  Handles form submission

  const handleSubmit = (e) => {
    e.preventDefault();                // prevent default page reload


    
    const validationErrors = validate();                  // validate input fields

    if (Object.keys(validationErrors).length === 0) {
      onAddStudent(formData);                                 // add or update student
      setFormData({ name: '', email: '', course: '', image: '' });    // reset form
      setErrors({});
    } else {
      setErrors(validationErrors);                               // show validation messages
    }
  };

  return (
    <form onSubmit={handleSubmit}>

      <h2>{editingStudent ? 'Edit Student' : 'Add Student'}</h2>

      <FormInput
  label="Name"
  name="name"
  value={formData.name}
  onChange={handleChange}
  error={errors.name}
      />


      <FormInput
  label="Email"
  name="email"
  value={formData.email}
  onChange={handleChange}
  error={errors.email}
/>


      <div>
        <label>Course:</label><br />
        <select name="course" value={formData.course} onChange={handleChange}>
          <option value="">--Select Course--</option>
          {courses.map((c, i) => (
            <option key={i} value={c}>{c}</option>
          ))}
        </select>
        <div style={{ color: 'red' }}>{errors.course}</div>
        {loading && <p style={{ fontSize: '12px', color: 'gray' }}>Loading courses...</p>}
      </div>

      <FormInput
  label="Image URL"
  name="image"
  value={formData.image}
  onChange={handleChange}
/>


      <button type="submit">{editingStudent ? 'Update Student' : 'Add Student'}</button>
    </form>
  );
};

export default StudentForm;

