
import React from 'react';

const StudentList = ({ students, onEdit }) => {
  if (!students || students.length === 0) {
    return <p>No students added yet.</p>;
  }

  return (
    <table>

      <thead>
        <tr>
          <th>Image</th>
          <th>Name</th>
          <th>Email</th>
          <th>Course</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {students.map((student, index) => (
          <tr key={index}>
            <td>
              {student.image ? (
                <img src={student.image} alt="student" width="60" />
              ) : (
                'No Image'
              )}
            </td>
            <td>{student.name}</td>
            <td>{student.email}</td>
            <td>{student.course}</td>
            <td>
              <button onClick={() => onEdit(index)}>Edit</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default StudentList;
