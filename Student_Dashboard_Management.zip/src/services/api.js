// Simulating API call for course list using async/await
export const fetchCourses = async () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(['React', 'Node', 'Python', 'Java']);
    }, 1000); // Simulate network delay
  });
};
