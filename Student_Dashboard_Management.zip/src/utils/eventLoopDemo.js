// Demonstrates async/await + setTimeout to explain the event loop
export const simulateAsyncProcess = async () => {
  console.log("Event loop demo: start");
  

  //  Wrapping setTimeout in a Promise and awaiting it

  await new Promise(resolve => {
    setTimeout(() => {
      console.log("Inside setTimeout (2s delay)");
      resolve();
    }, 2000);
  });
  
  // This log runs after the async delay is resolved
  
  console.log("Event loop demo: end");
};
